package course_work;

public interface LeagueManager {

    void addingClub();
    void deleteClub();
    void displayStatics();
    void displayTable();
    void addMatch();
    void randomMatch();

}
